export default function Header() {
  return (
    <header className="fixed top-0 w-full bg-teal-50 shadow-sm z-50">
      <nav className="max-w-6xl mx-auto px-6 py-4 flex items-center justify-between">
        <div className="flex items-center gap-2 animate-fade-in">
          <div className="w-8 h-8 bg-gradient-to-br from-teal-500 to-teal-700 rounded-lg flex items-center justify-center">
            <span className="text-white font-bold text-lg">IC</span>
          </div>
          <div>
            <h1 className="text-xl font-bold text-teal-900">Issa Cleaners</h1>
            <p className="text-xs text-teal-600">Nakuru, Kenya</p>
          </div>
        </div>

        <div className="hidden md:flex gap-8 items-center">
          <a href="#services" className="text-teal-700 hover:text-teal-900 font-medium transition-colors">
            Services
          </a>
          <a href="#why-us" className="text-teal-700 hover:text-teal-900 font-medium transition-colors">
            Why Us
          </a>
          <a href="#contact" className="text-teal-700 hover:text-teal-900 font-medium transition-colors">
            Contact
          </a>
        </div>

        <button className="px-6 py-2 bg-gradient-to-r from-teal-600 to-teal-700 text-white rounded-lg font-semibold hover:shadow-lg hover:shadow-teal-200 transition-all duration-300 animate-pulse-subtle">
          Get Quote
        </button>
      </nav>
    </header>
  )
}
