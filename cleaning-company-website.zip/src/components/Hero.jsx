export default function Hero() {
  return (
    <section className="pt-32 pb-16 bg-gradient-to-b from-teal-50 to-white">
      <div className="max-w-6xl mx-auto px-6">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div className="animate-slide-up">
            <h2 className="text-5xl md:text-6xl font-bold text-teal-900 mb-6 leading-tight">
              Your Space,{" "}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-teal-600 to-teal-400">Spotless</span>
            </h2>
            <p className="text-xl text-teal-700 mb-8 leading-relaxed">
              Professional cleaning services for homes and businesses across Nakuru. We bring excellence and attention
              to detail to every project.
            </p>
            <div className="flex gap-4">
              <button className="px-8 py-3 bg-gradient-to-r from-teal-600 to-teal-700 text-white rounded-lg font-semibold hover:shadow-xl hover:shadow-teal-300 transition-all duration-300 hover:scale-105">
                Book Now
              </button>
              <button className="px-8 py-3 border-2 border-teal-600 text-teal-700 rounded-lg font-semibold hover:bg-teal-50 transition-all duration-300">
                Learn More
              </button>
            </div>
          </div>

          <div className="relative h-96 animate-float">
            <div className="absolute inset-0 bg-gradient-to-br from-teal-400 to-teal-600 rounded-2xl opacity-20 blur-3xl animate-pulse"></div>
            <div className="relative h-full bg-gradient-to-br from-teal-100 to-teal-50 rounded-2xl flex items-center justify-center border border-teal-200">
              <div className="text-6xl">✨</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
