export default function WhyUs() {
  const reasons = [
    {
      number: "01",
      title: "Experienced Team",
      description: "Over 10 years of professional cleaning experience across Nakuru",
    },
    {
      number: "02",
      title: "Quality Guaranteed",
      description: "We use eco-friendly products and proven cleaning methods",
    },
    {
      number: "03",
      title: "Affordable Pricing",
      description: "Competitive rates without compromising on quality or service",
    },
  ]

  return (
    <section id="why-us" className="py-20 bg-gradient-to-b from-teal-50 to-white">
      <div className="max-w-6xl mx-auto px-6">
        <div className="text-center mb-16 animate-slide-up">
          <h3 className="text-4xl font-bold text-teal-900 mb-4">Why Choose Issa Cleaners</h3>
          <p className="text-lg text-teal-600">Excellence in every detail</p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {reasons.map((reason, index) => (
            <div key={index} className="group animate-fade-in" style={{ animationDelay: `${index * 200}ms` }}>
              <div className="text-6xl font-bold text-teal-200 group-hover:text-teal-400 transition-colors duration-300 mb-4">
                {reason.number}
              </div>
              <h4 className="text-2xl font-bold text-teal-900 mb-3">{reason.title}</h4>
              <p className="text-teal-700 leading-relaxed">{reason.description}</p>
              <div className="h-1 w-0 bg-gradient-to-r from-teal-600 to-teal-400 mt-4 group-hover:w-12 transition-all duration-300"></div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
