export default function Contact() {
  return (
    <section id="contact" className="py-20 bg-white">
      <div className="max-w-4xl mx-auto px-6">
        <div className="text-center mb-12 animate-slide-up">
          <h3 className="text-4xl font-bold text-teal-900 mb-4">Get In Touch</h3>
          <p className="text-lg text-teal-600">Ready to transform your space? Contact us today</p>
        </div>

        <div className="grid md:grid-cols-2 gap-8 mb-12">
          <div className="bg-teal-50 p-8 rounded-xl border border-teal-200 animate-scale-in">
            <h4 className="text-xl font-bold text-teal-900 mb-6">Contact Info</h4>
            <div className="space-y-4">
              <div className="flex gap-4">
                <span className="text-2xl">📍</span>
                <div>
                  <p className="font-semibold text-teal-900">Nakuru, Kenya</p>
                  <p className="text-teal-600">Serving the entire Nakuru region</p>
                </div>
              </div>
              <div className="flex gap-4">
                <span className="text-2xl">📞</span>
                <div>
                  <p className="font-semibold text-teal-900">+254 123 456 789</p>
                  <p className="text-teal-600">Available Monday - Saturday</p>
                </div>
              </div>
              <div className="flex gap-4">
                <span className="text-2xl">📧</span>
                <div>
                  <p className="font-semibold text-teal-900">info@issacleaners.ke</p>
                  <p className="text-teal-600">We'll respond within 24 hours</p>
                </div>
              </div>
            </div>
          </div>

          <form className="space-y-4 animate-scale-in" style={{ animationDelay: "100ms" }}>
            <input
              type="text"
              placeholder="Your Name"
              className="w-full px-4 py-3 border-2 border-teal-200 rounded-lg focus:outline-none focus:border-teal-600 focus:bg-teal-50 transition-all"
            />
            <input
              type="email"
              placeholder="Your Email"
              className="w-full px-4 py-3 border-2 border-teal-200 rounded-lg focus:outline-none focus:border-teal-600 focus:bg-teal-50 transition-all"
            />
            <textarea
              placeholder="Tell us about your cleaning needs"
              rows="4"
              className="w-full px-4 py-3 border-2 border-teal-200 rounded-lg focus:outline-none focus:border-teal-600 focus:bg-teal-50 transition-all resize-none"
            />
            <button className="w-full px-6 py-3 bg-gradient-to-r from-teal-600 to-teal-700 text-white rounded-lg font-semibold hover:shadow-lg hover:shadow-teal-200 transition-all duration-300 hover:scale-105">
              Send Message
            </button>
          </form>
        </div>
      </div>
    </section>
  )
}
