export default function Footer() {
  return (
    <footer className="bg-teal-900 text-teal-50">
      <div className="max-w-6xl mx-auto px-6 py-12">
        <div className="grid md:grid-cols-4 gap-8 mb-8">
          <div>
            <div className="flex items-center gap-2 mb-4">
              <div className="w-8 h-8 bg-teal-400 rounded-lg flex items-center justify-center">
                <span className="text-teal-900 font-bold">IC</span>
              </div>
              <span className="font-bold text-lg">Issa Cleaners</span>
            </div>
            <p className="text-teal-200">Professional cleaning services in Nakuru, Kenya</p>
          </div>

          <div>
            <h5 className="font-bold mb-4">Services</h5>
            <ul className="space-y-2 text-teal-200">
              <li>
                <a href="#" className="hover:text-teal-50 transition-colors">
                  Home Cleaning
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-teal-50 transition-colors">
                  Office Cleaning
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-teal-50 transition-colors">
                  Deep Cleaning
                </a>
              </li>
            </ul>
          </div>

          <div>
            <h5 className="font-bold mb-4">Company</h5>
            <ul className="space-y-2 text-teal-200">
              <li>
                <a href="#" className="hover:text-teal-50 transition-colors">
                  About Us
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-teal-50 transition-colors">
                  Contact
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-teal-50 transition-colors">
                  Blog
                </a>
              </li>
            </ul>
          </div>

          <div>
            <h5 className="font-bold mb-4">Follow Us</h5>
            <div className="flex gap-4">
              <a
                href="#"
                className="w-10 h-10 bg-teal-700 rounded-lg flex items-center justify-center hover:bg-teal-600 transition-colors"
              >
                f
              </a>
              <a
                href="#"
                className="w-10 h-10 bg-teal-700 rounded-lg flex items-center justify-center hover:bg-teal-600 transition-colors"
              >
                𝕏
              </a>
              <a
                href="#"
                className="w-10 h-10 bg-teal-700 rounded-lg flex items-center justify-center hover:bg-teal-600 transition-colors"
              >
                in
              </a>
            </div>
          </div>
        </div>

        <div className="border-t border-teal-800 pt-8 text-center text-teal-200">
          <p>&copy; 2025 Issa Cleaners. All rights reserved. Nakuru, Kenya</p>
        </div>
      </div>
    </footer>
  )
}
