// Update this file with the services provided by Issa Cleaners
export const services = [
  {
    id: 1,
    name: "Home Cleaning",
    description: "Professional home cleaning for residential properties in Nakuru",
    icon: "🏠",
  },
  {
    id: 2,
    name: "Office Cleaning",
    description: "Maintain a clean and professional workspace for your business",
    icon: "🏢",
  },
  {
    id: 3,
    name: "Deep Cleaning",
    description: "Thorough cleaning services for spring cleaning and special occasions",
    icon: "✨",
  },
  {
    id: 4,
    name: "Carpet & Upholstery",
    description: "Expert carpet and furniture cleaning to extend their lifespan",
    icon: "🛋️",
  },
  {
    id: 5,
    name: "Window Cleaning",
    description: "Crystal clear windows for your home or business premises",
    icon: "🪟",
  },
  {
    id: 6,
    name: "Post-Construction Cleaning",
    description: "Remove construction debris and dust after renovation projects",
    icon: "🔨",
  },
]
