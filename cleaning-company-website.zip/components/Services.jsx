import { services } from "@/lib/services"

export default function Services() {
  return (
    <section id="services" className="py-20 bg-white">
      <div className="max-w-6xl mx-auto px-6">
        <div className="text-center mb-16 animate-slide-up">
          <h3 className="text-4xl font-bold text-teal-900 mb-4">Our Services</h3>
          <p className="text-lg text-teal-600">Comprehensive cleaning solutions tailored to your needs</p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map((service, index) => (
            <div
              key={service.id}
              className="group p-6 bg-teal-50 rounded-xl border border-teal-200 hover:border-teal-400 transition-all duration-300 hover:shadow-lg hover:shadow-teal-100 hover:-translate-y-2 animate-scale-in"
              style={{ animationDelay: `${index * 100}ms` }}
            >
              <div className="text-4xl mb-4 group-hover:scale-110 transition-transform duration-300">
                {service.icon}
              </div>
              <h4 className="text-xl font-bold text-teal-900 mb-2">{service.name}</h4>
              <p className="text-teal-700">{service.description}</p>
              <button className="mt-4 text-teal-600 font-semibold hover:text-teal-800 flex items-center gap-2 group-hover:gap-3 transition-all">
                Learn More <span>→</span>
              </button>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
